//
//  main.c
//  data_struct_project
//
//  Created by Edward dawson on 30/04/2018.
//  Copyright © 2018 ziyu zhu. All rights reserved.
//


#include "hash.h"
#define mode 1

int main(int argc, const char * argv[]) {
     //定义所有变量
    FILE *inFile, *outFile;
    char *prefix1 = (char *) malloc (sizeof(char)), *prefix2 = (char *) malloc (sizeof(char)), *suffix1 = (char *) malloc (sizeof(char)), *tmpChar;
    char *prefix1Const = (char *) malloc (sizeof(char)), *prefix2Const = (char *) malloc (sizeof(char));
    int maxWord, n;
    ll hashValue;
    suffix *result;
    extern node hashTable[MAXSIZE];
    
    //变量初始化
    if(mode == 1)
        inFile = fopen("article.txt", "r");
    else
        inFile = fopen("/Users/edward/desktop/article1.txt", "r");
    outFile = fopen("markov.txt", "w");
    scanf("%d", &maxWord);
    maxWord -= 2;
    fscanf(inFile, "%s %s", prefix1, prefix2);
    strcpy(prefix2Const, prefix2);
    strcpy(prefix1Const, prefix1);
    
    //读入suffix 并且hash
    init();
    while(fscanf(inFile, "%s", suffix1) != EOF)
    {
        push(prefix1, prefix2, suffix1);
        tmpChar = prefix1;
        prefix1 = prefix2;
        prefix2 = suffix1;
        suffix1= tmpChar;
    }
    *suffix1 = '\0';
    push(prefix1, prefix2, suffix1);
    
    //搜索并且生成文件
    strcpy(prefix1, prefix1Const);
    strcpy(prefix2, prefix2Const);
    if(mode == 1)
        fprintf(outFile, "%s %s ", prefix1, prefix2);
    else
        printf("%s %s ", prefix1, prefix2);
    while(maxWord--)
    {
        hashValue = search(prefix1, prefix2);
        if(hashTable[hashValue].len == 1)
            result = &hashTable[hashValue].head;
        else
        {
            n = (int)(rrand() * hashTable[hashValue].len) + 1;
            result = getNthSuffix(&hashTable[hashValue].head, n);
        }
        if((result->s)[0] == '\0')
            break;
        else
        {
            if(mode == 1)
                fprintf(outFile, "%s ", result->s);
            else
                printf("%s ", result->s);
            tmpChar = prefix1;
            prefix1 = prefix2;
            prefix2 = tmpChar;
            strcpy(prefix2, result->s);
        }
    }
    
    //关闭文件 释放内存
    fclose(inFile);
    fclose(outFile);
    return 0;
}
